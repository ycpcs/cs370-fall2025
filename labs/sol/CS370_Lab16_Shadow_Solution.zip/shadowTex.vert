#version 400 core
uniform mat4 model_matrix;
uniform mat4 proj_matrix;
uniform mat4 camera_matrix;
uniform mat4 light_proj_matrix;
uniform mat4 light_cam_matrix;

layout(location = 0) in vec4 vPosition;
layout(location = 1) in vec2 vTexCoord;

out vec2 texCoord;
out vec4 LightPosition;

void main( )
{
    // Compute transformed vertex position in view space
    gl_Position = proj_matrix*(camera_matrix*(model_matrix*vPosition));

    // Pass texture coordinate to frag shader
    texCoord = vTexCoord;

    // Compute vertex position in world coordinates (passed to fragment shader)
    vec4 Position = model_matrix*vPosition;

    // Compute vertex in light space
    LightPosition = light_proj_matrix*(light_cam_matrix*Position);

}
