#version 400 core
uniform sampler2D tex;
uniform sampler2D shadowMap;

uniform bool ShadowOn;

out vec4 fragColor;

in vec2 texCoord;
in vec4 LightPosition;

// TODO: Perform shadow depth comparison
float ShadowCalculation(vec4 fragLightPos) {
    // Normalize light position [-1, 1]
    vec3 projCoords = fragLightPos.xyz/fragLightPos.w;

    // Convert to depth range [0, 1]
    projCoords = projCoords*0.5 + 0.5;

    float closestDepth = texture(shadowMap, projCoords.xy).r;
    float curDepth = projCoords.z;

    float bias = 0.005;
    return curDepth - bias > closestDepth ? 1.0f : 0.0f;
}

void main()
{
    // Sample texture map
    // TODO: Determine if fragment (LightPosition) is in shadow
    float shadow = 1.0;
    if (ShadowOn) {
        shadow = 1.0 - ShadowCalculation(LightPosition);
    }
    fragColor = shadow*texture(tex, texCoord);
}
