#version 400 core

layout(location = 0) in vec4 vPosition;
layout(location = 1) in vec2 vTexCoord;

uniform mat4 proj_matrix;
uniform mat4 camera_matrix;
uniform mat4 model_matrix;
uniform mat4 light_proj_matrix;
uniform mat4 light_cam_matrix;

out vec2 texCoord;
out vec4 LightPosition;

void main( )
{
    // Compute transformed vertex position in view space
    gl_Position = proj_matrix*(camera_matrix*(model_matrix*vPosition));

    // TODO: Pass texture coordinate to frag shader
    texCoord = vTexCoord;
    
    // Compute vertex position in world coordinates
    vec4 Position = model_matrix*vPosition;

    // TODO: Compute vertex in light space
    LightPosition = light_proj_matrix*(light_cam_matrix*Position);

}
