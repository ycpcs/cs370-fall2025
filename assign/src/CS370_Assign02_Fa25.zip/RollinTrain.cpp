// CS370 Assignment 2 - Rollin Train
// Fall 2025

#include <stdio.h>
#include <vector>
#include "../common/vgl.h"
#include "../common/objloader.h"
#include "../common/utils.h"
#include "../common/vmath.h"
#include "RollinTrain.h"
#define DEG2RAD (M_PI/180.0)
#define RAD2DEG (180.0f/3.14159f)

using namespace vmath;
using namespace std;

// Vertex array and buffer names
enum VAO_IDs {Cube, Cylinder, Cone, Torus, Axes, NumVAOs};
enum Obj_Buffer_IDs {PosBuffer, NormBuffer, TexBuffer, NumObjBuffers};
enum Color_Buffer_IDs {TiesColor, RailColor, BodyColor, EngColor, CylColor, ConeColor,
        WheelColor, SpokeColor, BottomColor, MiddleColor, TopColor, AxesColor, NumColorBuffers};

// Vertex array and buffer objects
GLuint VAOs[NumVAOs];
GLuint ObjBuffers[NumVAOs][NumObjBuffers];
GLuint ColorBuffers[NumColorBuffers];

// Number of vertices in each object
GLint numVertices[NumVAOs];

// Number of component coordinates
GLint posCoords = 4;
GLint normCoords = 3;
GLint texCoords = 2;
GLint colCoords = 4;

GLfloat axis_length = 3.0f;

// Model files
const char * cubeFile = "../models/unitcube.obj";
const char * cylinderFile = "../models/cylinder.obj";
const char * coneFile = "../models/cone.obj";
const char * torusFile = "../models/torus.obj";

// Camera
vec3 eye = {3.0f, 3.0f, 3.0f};
vec3 center = {0.0f, 0.0f, 0.0f};
vec3 up = {0.0f, 1.0f, 0.0f};

// Shader variables
// Shader program reference
GLuint default_program;
// Shader component references
GLuint default_vPos;
GLuint default_vCol;
GLuint default_proj_mat_loc;
GLuint default_cam_mat_loc;
GLuint default_model_mat_loc;
const char *default_vertex_shader = "../default.vert";
const char *default_frag_shader = "../default.frag";

// Global state
mat4 proj_matrix;
mat4 camera_matrix;
mat4 model_matrix;

// Global state
GLdouble elTime = 0.0;
GLdouble speed = (RAIL_LENGTH/4.0f);
vec3 train_pos = {0.0f, 0.0f, 0.0f};
GLint train_dir = -1;
GLfloat wheel_ang = 0.0f;
GLboolean animate = false;

// Global spherical coord values
GLfloat azimuth = 45.0f;
GLfloat daz = 2.0f;
GLfloat elevation = 53.5f;
GLfloat del = 2.0f;
GLfloat radius = 5.0f;
GLfloat dr = 0.1f;
GLfloat min_radius = 2.0f;

// View modes
#define ORTHOGRAPHIC 0
#define PERSPECTIVE 1
int proj = ORTHOGRAPHIC;

// Component indices
#define X 0
#define Y 1
#define Z 2

// Global screen dimensions
GLint ww,hh;

void display( );
void render_scene( );
void build_geometry( );
void load_model(const char * filename, GLuint obj);
void build_solid_color_buffer(GLuint num_vertices, vec4 color, GLuint buffer);
void draw_color_obj(GLuint obj, GLuint color);
void framebuffer_size_callback(GLFWwindow *window, int width, int height);
void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods);
void mouse_callback(GLFWwindow *window, int button, int action, int mods);
void build_axes();
void draw_axes();

int main(int argc, char**argv)
{
	// Create OpenGL window
	GLFWwindow* window = CreateWindow("Rollin Train 2022");
    if (!window) {
        fprintf(stderr, "ERROR: could not open window with GLFW3\n");
        glfwTerminate();
        return 1;
    } else {
        printf("OpenGL window successfully created\n");
    }

    // Store initial window size
    glfwGetFramebufferSize(window, &ww, &hh);

    // Register callbacks
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetKeyCallback(window,key_callback);
    glfwSetMouseButtonCallback(window, mouse_callback);

	// Create geometry buffers
    build_geometry();

    // Load shaders and associate variables
    ShaderInfo default_shaders[] = { {GL_VERTEX_SHADER, default_vertex_shader},{GL_FRAGMENT_SHADER, default_frag_shader},{GL_NONE, NULL} };
    default_program = LoadShaders(default_shaders);
    default_vPos = glGetAttribLocation(default_program, "vPosition");
    default_vCol = glGetAttribLocation(default_program, "vColor");
    default_proj_mat_loc = glGetUniformLocation(default_program, "proj_matrix");
    default_cam_mat_loc = glGetUniformLocation(default_program, "camera_matrix");
    default_model_mat_loc = glGetUniformLocation(default_program, "model_matrix");

    // Enable depth test
    //glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);

    // Set background color
    glClearColor(1.0f,1.0f,1.0f,1.0f);

    // Set Initial camera position
    GLfloat x, y, z;
    x = (GLfloat)(radius*sin(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));
    y = (GLfloat)(radius*cos(elevation*DEG2RAD));
    z = (GLfloat)(radius*cos(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));
    eye = vec3(x, y, z);

    // Set initial time
    elTime = glfwGetTime();

    // Start loop
    while ( !glfwWindowShouldClose( window ) ) {
    	// Draw graphics
        display();
        // Update other events like input handling
        glfwPollEvents();
        if (animate) {
            // TODO: Add animation

        }
        // Swap buffer onto screen
        glfwSwapBuffers( window );
    }

    // Close window
    glfwTerminate();
    return 0;
}

void display( )
{
    // Declare projection and camera matrices
    proj_matrix = mat4().identity();
    camera_matrix = mat4().identity();

    // Clear window and depth buffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Compute anisotropic scaling
    GLfloat xratio = 1.0f;
    GLfloat yratio = 1.0f;
    // If taller than wide adjust y
    if (ww <= hh)
    {
        yratio = (GLfloat)hh / (GLfloat)ww;
    }
        // If wider than tall adjust x
    else if (hh <= ww)
    {
        xratio = (GLfloat)ww / (GLfloat)hh;
    }

    // TODO: Set projection and camera matrices
    // Position camera for orthographic projection
    if (proj == ORTHOGRAPHIC)
    {
        // TODO: Set orthographic (birds-eye) view (spherical coords)
        proj_matrix = ortho(-5.0f, 5.0f, -5.0f, 5.0f, -10.0f, 10.0f);
    }
    // Position camera for perspective projection
    else if (proj == PERSPECTIVE)
    {
        // TODO: Set dynamic perspective (first-person) view

    }
    camera_matrix = lookat(eye, center, up);
    // Render objects
    render_scene();

    // draw axes
    draw_axes();

    // Flush pipeline
    glFlush();
}

void render_scene( ) {
    // Declare transformation matrices
    model_matrix = mat4().identity();
    mat4 scale_matrix = mat4().identity();
    mat4 rot_matrix = mat4().identity();
    mat4 trans_matrix = mat4().identity();

    // TODO: Draw objects
    // Draw cube
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    draw_color_obj(Cube, BodyColor);

}

void build_geometry( )
{
    // Generate vertex arrays and buffers
    glGenVertexArrays(NumVAOs, VAOs);

    // TODO: Load models
    load_model(cubeFile, Cube);

    // Generate color buffers
    glGenBuffers(NumColorBuffers, ColorBuffers);

    // TODO: Create color buffers
    // Create body color (cube)
    build_solid_color_buffer(numVertices[Cube], body_color, BodyColor);


    // Build axes
    build_axes();
}

void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods) {
    // ESC to quit
    if (key == GLFW_KEY_ESCAPE) {
        glfwSetWindowShouldClose(window, true);
    }

    // Toggle projection mode
    if (key == GLFW_KEY_O)
    {
        proj = ORTHOGRAPHIC;
    }
    else if (key == GLFW_KEY_P)
    {
        proj = PERSPECTIVE;
    }

    // TODO: Add keypress functionality

}

void mouse_callback(GLFWwindow *window, int button, int action, int mods){

}

#include "utilfuncs.cpp"
